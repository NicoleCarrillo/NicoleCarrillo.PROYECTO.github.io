﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Canion : MonoBehaviour
{

    public GameObject original;
    public Transform referencia;
    private IEnumerator disparo;


    private bool plus=false;

    private IEnumerator disparopLUS;
    // Start is called before the first frame update
    void Start()
    {
        disparo=Disparar();
        disparopLUS = DispararPlus();
    }

    // Update is called once per frame
    void Update()
    {

         if(Input.GetKeyDown(KeyCode.Space)){
             if(plus==false){
            StartCoroutine(disparo);
             }else{
                StartCoroutine(disparopLUS); 
             }
        }

        if(Input.GetKeyUp(KeyCode.Space)){
            if(plus==false){
            StopCoroutine(disparo);
            }else{
                StopCoroutine(disparopLUS);
            }
        }

        float h=Input.GetAxis("Horizontal");
        float v=Input.GetAxis("Vertical");

       
        transform.Translate(h*5*Time.deltaTime,v*5*Time.deltaTime,0);
        

        
    }

 

    IEnumerator Disparar(){
        while(true){
            //Instanciar bala
            Instantiate(original,referencia.position,referencia.rotation);
            yield return new WaitForSeconds(0.2f);
            
        }
    }

    IEnumerator DispararPlus(){
        while(true){
            //Instanciar bala
            Instantiate(original,referencia.position,referencia.rotation);
            yield return new WaitForSeconds(0.03f);
            
        }
    }

    private void OnCollisionEnter(Collision collision){
        if(collision.gameObject.tag=="UP"){
            Destroy(collision.gameObject);
            plus=true;
        }
    }
}
