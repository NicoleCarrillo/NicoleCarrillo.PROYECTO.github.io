﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine;
using UnityEngine.UI;

public class Proyectil : MonoBehaviour
{

    //Recuperar una referencia al componente rigidbody de este game object

    Rigidbody rb;
    public Text texto;

    public int puntos=0;

    // Start is called before the first frame update
    void Start()
    {
        //Puede ser null
        rb=GetComponent<Rigidbody>();

        //Podemos obtener varios si hay

        Rigidbody[] rbs=GetComponents<Rigidbody>();
        //rb.AddForce(new Vector3(0,5,-10),ForceMode.Impulse);
        rb.AddForce(transform.up*11,ForceMode.Impulse);
        Destroy(gameObject,3);

        texto.text = "PUNTOS!";
    }

    
    private void OnCollisionEnter(Collision collision){
        puntos=puntos+10;
        print(puntos);
        if(collision.gameObject.tag=="COSO"){
            Destroy(collision.gameObject);
            Destroy(gameObject);
        }
        texto.text=puntos.ToString();
    }
}